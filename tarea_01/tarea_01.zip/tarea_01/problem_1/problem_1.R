
# Nos movemos al directorio donde se encuentran los datos
# (Se puede modificar el path para revision)
setwd("/home/randy/Escritorio/Semestre/patrones/tareas/tarea_01/problem_1")

############################################################################
################## Lectura de datos y preprocesamiento #####################
############################################################################
score <- read.table("deport.dat")
print(head(score))

# Guardamos los paises y los removemos del dataframe
country <- score[,9]
score <- score[,1:8]

# A cada fila le asignamos como nombre su pais correspondiente
rownames(score) <- country
print(head(score))

# Graficamos ... Observamos que tienen forma de nube
plot(score)

# Parece que los primeros 3 tiempos están medidos en segundos 
# y las restantes en minutos
#   Se supone estan ordenados por distancia, por lo que no me 
#   parece logico que de 40 u de tiempo pasen a 2 u de tiempo 
#   en una distancia mayor
# check_ordering <- score$V3 < score$V4 # Cambiar (3,4) por (1,2),(2,3), ... ,(7,8)
# check_ordering[check_ordering == FALSE]

# Entonces pasamos todo a segundos (¿Esto se puede hacer?¿Obtendremos resultados diferentes?)
# score[4:8] <- score[4:8] * 60
# print(head(score))
# check_ordering <- score$V1 < score$V2 # Cambiar (1,2) por (2,3),(3,4), ... ,(7,8)
# check_ordering[check_ordering == FALSE]

############################################################################
###############      Media, Covarianza y Correlacion      ##################
############################################################################

EX <- colMeans(score)
print(EX)

VarX <- cov(score)
print(VarX)

CorX <- cor(score)
print(CorX)

############################################################################
##################          Centrar los datos          #####################
############################################################################
#X <- data.matrix(score)
#n <- nrow(score)

#Matriz identidad
#identity <- diag(n)
# Vector de unos
#ones <- rep(1, n)
# Matriz para centrar
#C <- identity - (1 / n) * (ones %*% t(ones))

# Centramos los datos
#Xc <- C %*% X

############################################################################
##################           Estimar Cov(X)             ####################
############################################################################

# covX <- (1 / n) * (t(Xc) %*% Xc)
# print(covX)

# Observamos que es una aproximacion parecida a la que devuelve R
# print(covX - VarX)

#Hacemos escalamiento de los datos en columnas(de ahi proviene el "2")
# scaled_score <- apply(Xc, 2, scale) # Creo que con esta linea no hace falta calcular C
# head(scaled_score)

#Observamos la varianza de cada columna
# apply(scaled_score, 2, var)

############################################################################
##################    Centrar y reescalar los datos    #####################
############################################################################

# Hacemos PCA con los datos normalizados y centrados
pca = prcomp(score , center = TRUE, scale = TRUE)
# Observamos la varianza explicada en cada componente ... con las primeras dos ya tenemos 93%
summary(pca)
print(pca)

############################################################################
###############   Matriz de eigenvectores (Direcciones)   ##################
############################################################################

print(pca$rotation)

plot(pca$sdev^2, xlab = "Component number", ylab = "Component variance", type = "l")

############################################################################
###############     Observaciones en el nuevo espacio     ##################
############################################################################

print(head(pca$x))

############################################################################
###############    Vector Media y vector de Varianzas     ##################
############################################################################

print(pca$center)
print(pca$scale ** 2)
print(pca$sdev)

xlim <- range(pca$x[,1])
plot(pca$x[,1:2], xlim = xlim, ylim = xlim)

# El punto con menor valor en la primera componente
points(pca$x[c("usa"),1], pca$x[c("usa"),2], col="blue")

# El punto con mayor valor en la primera componente
points(pca$x[c("cookis"),1], pca$x[c("cookis"),2], col="red")


print(score)