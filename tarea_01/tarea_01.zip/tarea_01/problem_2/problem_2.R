
# Nos movemos al directorio donde se encuentran los datos
setwd("/home/randy/Escritorio/Semestre/patrones/tareas/tarea_01/problem_2")

############################################################################
################## Lectura de datos y preprocesamiento #####################
############################################################################

temp <- matrix(scan("oef2.data.dat"), 35, 12, byrow=T)

nombresestaciones <- c("St. John_s", "Charlottetown", "Halifax" ,
                       "Sydney", "Yarmouth", "Fredericton",
                       "Arvida", "Montreal", "Quebec City",
                       "Schefferville", "Sherbrooke", "Kapuskasing",
                       "London", "Ottawa", "Thunder Bay",
                       "Toronto", "Churchill", "The Pas",
                       "Winnipeg", "Prince Albert", "Regina",
                       "Beaverlodge", "Calgary", "Edmonton",
                       "Kamloops", "Prince George", "Prince Rupert",
                       "Vancouver", "Victoria", "Dawson",
                       "Whitehorse", "Frobisher Bay", "Inuvik",
                       "Resolute", "Yellowknife")

rownames(temp) <- nombresestaciones
temp <- as.data.frame(temp)
print(head(temp))

# Grafica de dispersion ...
plot(temp)

############################################################################
###############      Media, Covarianza y Correlacion      ##################
############################################################################

EX <- colMeans(temp)
print(EX)

VarX <- cov(temp)
print(VarX)

CorX <- cor(temp)
print(CorX)

############################################################################
##################    Centrar y reescalar los datos    #####################
############################################################################

# Hacemos PCA con los datos normalizados y centrados
pca = prcomp(temp , center = TRUE, scale = TRUE)
# Observamos la varianza explicada en cada componente ... con las primeras dos ya tenemos 93%
summary(pca)
print(pca)

############################################################################
###############   Matriz de eigenvectores (Direcciones)   ##################
############################################################################

print(pca$rotation)

plot(pca$sdev^2, xlab = "Component number", ylab = "Component variance", type = "l")

xlim <- range(pca$x[,1])
plot(pca$x[,1:2], xlim = xlim, ylim = xlim)

# Mayor valor en primera componente principal
points(pca$x[c("Resolute"),1], pca$x[c("Resolute"),2], col="blue")

# Menor valor en primera componente principal
points(pca$x[c("Vancouver"),1], pca$x[c("Vancouver"),2], col="red")
points(pca$x[c("Victoria"),1], pca$x[c("Victoria"),2], col="blue")
points(pca$x[c("Kamloops"),1], pca$x[c("Kamloops"),2], col="orange")



# Mayor valor en segunda componente principal
points(pca$x[c("Prince Rupert"),1], pca$x[c("Prince Rupert"),2], col="blue")

# Menor valor en primera componente principal
points(pca$x[c("Dawson"),1], pca$x[c("Dawson"),2], col="red")

############################################################################
###############    Grafica de componentes principales     ##################
############################################################################

plot(1:12, pca$rotation[,2], col="red", type="l")
points(1:12, pca$rotation[,1], col="blue", type="l")

